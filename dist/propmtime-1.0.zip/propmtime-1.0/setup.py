
from distutils.core import setup
setup(name='propmtime',
      version='1.0',
      packages=['propmtime'],
      url='http://github.com/latusrepo/propmtime',
      author='James Abel',
      author_email='j@abel.co'
      )